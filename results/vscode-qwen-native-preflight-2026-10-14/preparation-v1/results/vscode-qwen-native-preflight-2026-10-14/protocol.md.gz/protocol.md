# Prospective native editor check

This is a five-window integration fixture. No native model, editor, service,
runtime freeze or package installation has run for this protocol yet.

The wrapper uses the new isolated reranker interpreter and checkpoint under
`.cache/qwen-install-validation-2026-10-14`, the ordinary embedding environment,
and the already prepared pinned VS Code Development Host. It installs nothing.

After all 18 coding trials finish and their independent full-inventory audit
passes, complete and independently audit the fresh isolated installation,
416-pair production parity, and native HTTP/MCP smoke. The coding driver's
recorded PID and process group must also be gone. Use the exact completed gate
files, rather than a prefix audit or the older original-runtime certificates.

Commit the wrapper, launcher repair and CPU tests before freezing. From the
project root, choose new unused output and private work directories:

```sh
.venv/bin/python -B scripts/smoke_vscode_qwen.py --freeze \
  --output results/vscode-qwen-native-2026-10-14 \
  --work-dir .cache/vscode-qwen-native-2026-10-14 \
  --coding-audit PATH_TO_FULL18_INDEPENDENT_AUDIT \
  --setup-receipt PATH_TO_SUCCESSFUL_INSTALLER_JSON \
  --parity-audit PATH_TO_INSTALLED_PARITY_INDEPENDENT_AUDIT \
  --mcp-audit PATH_TO_INSTALLED_MCP_INDEPENDENT_AUDIT
```

Freeze reads metadata and creates the authored mixed-language fixture; it starts
no model/editor and performs no installation. Commit its `frozen-plan.json`,
then run the identical plan explicitly:

```sh
.venv/bin/python -B scripts/smoke_vscode_qwen.py --run \
  --output results/vscode-qwen-native-2026-10-14 \
  --work-dir .cache/vscode-qwen-native-2026-10-14
```

The actual run owns a Qwen subprocess under the private work directory and an
HTTP service with a fresh SQLite index. It invokes the existing optional host
case through `npm run host:smoke -- --run --qwen-reranker`. The additional saved,
dirty and reranking-disabled searches take their choices from normal fixture
folder settings, without programmatic search-option overrides.

Qualification requires two actual Qwen searches of the available five-window
pool: ten measured forwards, plus one separately identified startup warmup.
Literal query/source/tokenizer identities, finite score arithmetic, ordered
native events and cumulative counters must match the HTTP receipts. Published
and retained private ledgers must contain identical bytes. Compact token counts
and source/result caps are independently recounted from actual responses.

Embedding counters observe production API entries: five initial document texts,
eight search queries, and one changed document text for the dirty request. These
counts do not imply that the embedding model performed six native forwards.
The saved index manifest and five-window scope must remain unchanged.

The launcher publishes a private nonce/PID/group/executable/argument receipt
before queued signals can trigger cleanup. Its TERM/KILL and output drain are
bounded. The wrapper can additionally stop only that nonce-bound detached editor
group after a launcher interruption. Qualified cleanup and clean completion are
separate observations. Passing requires the actual owned worker group gone,
authentication file absent, both listeners closed, owned editor profile removed,
and no forced/failed/interrupted cleanup. Signals retain failure evidence and
are deferred during owned cleanup.

The prior 105-test provider qualification and launcher at `fd0e7d8` are retained.
The repair has 109 extension CPU tests and 12 Python CPU tests; these simulate
processes and receipts, not editor/native inference. New output paths are
required after an attempted failure; never overwrite or resume an attempt.

This check does not establish retrieval quality, coding correctness, paid-token
savings, fresh-machine performance or ordinary user-profile activation. VSIX
packaging and release/version decisions remain separate later steps.
