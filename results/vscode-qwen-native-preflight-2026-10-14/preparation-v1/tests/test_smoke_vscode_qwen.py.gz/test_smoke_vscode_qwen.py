"""Small CPU-only fixture gates; these never certify native inference or an editor."""
import copy
import importlib.util
import json
import os
from pathlib import Path

import pytest

from semantic_search.qwen_reranker_core import PairBuilder, binary_score
from semantic_search.qwen_worker import WARMUP

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("vscode_qwen_cpu", ROOT / "scripts/smoke_vscode_qwen.py")
smoke = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(smoke)


class CPUTokenizer:
    def encode(self, text, add_special_tokens=False):
        if text in ("yes", "no"):
            return [90001 if text == "yes" else 90002]
        return [ord(char) for char in text]


def fixture():
    builder = PairBuilder(CPUTokenizer())
    warmup = builder.build(WARMUP["query"], WARMUP["source"])
    identity = {"request_id": "generic-warmup", "batch_size": 1, "forward_number": 1, "warmup": True,
                "input_ids_sha256": smoke.sha(json.dumps(warmup["input_ids"], separators=(",", ":")).encode()),
                **{key: warmup[key] for key in ("query_sha256", "source_sha256", "delivered_sha256", "total_tokens")}}
    observations, rows = [], [identity | {"event": event} for event in ("started", "completed")]
    number = 1
    for dirty in (False, True):
        query = "Find the literal changed value" if dirty else "Find the saved value"
        result_rows, receipts = [], {}
        for index in range(5):
            number += 1
            source = f"def function_{index}():\n    return {index + int(dirty)}\n"
            identifier, request = f"window-{index}", f"request-{number}"
            built = builder.build(query, source)
            result = {key: value for key, value in built.items() if key not in ("input_ids", "source")} | binary_score(float(index), 0.)
            receipt = {"request_id": request, "batch_size": 1, "result": result,
                       "counts": {key: number for key in smoke.COUNTERS}}
            receipts[identifier] = receipt
            result_rows.append({"id": identifier, "source": source, "truncated": False,
                                "qwen_score": result["logit_difference"], "h2o_score": None})
            identity = {"request_id": request, "batch_size": 1, "forward_number": number, "warmup": False,
                        "input_ids_sha256": smoke.sha(json.dumps(built["input_ids"], separators=(",", ":")).encode()),
                        **{key: result[key] for key in ("query_sha256", "source_sha256", "delivered_sha256", "total_tokens")}}
            rows.extend([identity | {"event": "started"}, identity | {"event": "completed", "score": binary_score(float(index), 0.)}])
        observations.append({"query": query, "settings": {"overlays": [{"path": "src/delta.ts"}]} if dirty else {},
                             "response": {"rerank": True, "rerank_provider": "qwen", "candidate_windows": 5,
                                          "retrieval_candidate_windows": 5, "reranker_batch_size": 1,
                                          "results": result_rows, "reranker_receipts": receipts}})
    return builder, observations, rows, {key: 11 for key in smoke.COUNTERS}


def test_complete_cpu_literal_inventory_reconciles_but_performs_no_inference():
    builder, observations, rows, counts = fixture()
    result = smoke.verify_native(rows, observations, counts, builder=builder)
    assert result == {"started": 11, "completed": 11, "measured": 10, "warmup": 1,
                      "literal_pairs_reconstructed": 10, "tokenizer_input_hashes_exact": True}


@pytest.mark.parametrize("kind", ["count", "duplicate-event", "warmup", "tokenizer", "source", "provider", "scalar", "returned-score"])
def test_native_gate_rejects_mismatched_actual_evidence(kind):
    builder, observations, rows, counts = fixture()
    if kind == "count":
        counts["completed_forwards"] = 10
    elif kind == "duplicate-event":
        rows.append(copy.deepcopy(rows[-1]))
    elif kind == "warmup":
        rows[3]["warmup"] = True
    elif kind == "tokenizer":
        rows[2]["input_ids_sha256"] = "0" * 64
    elif kind == "source":
        observations[0]["response"]["results"][0]["source"] += "# wrong literal\n"
    elif kind == "provider":
        observations[1]["response"]["rerank_provider"] = "h2o"
    elif kind == "scalar":
        observations[0]["response"]["reranker_receipts"]["window-0"]["result"]["yes_rank_signal"] = .2
    else:
        observations[0]["response"]["results"][0]["qwen_score"] = 9.
    with pytest.raises(AssertionError):
        smoke.verify_native(rows, observations, counts, builder=builder)


def test_coding_gate_rejects_partial_inventory_and_live_owned_driver(tmp_path):
    audit = tmp_path / "audit.json"
    value = {"checks_passed": True, "inventory_complete": False, "final_completion_receipt": False,
             "recorded_attempts": 17, "missing_attempts": ["trial18"]}
    audit.write_text(json.dumps(value))
    with pytest.raises(AssertionError, match="Full18"):
        smoke.coding_gate(audit)
    value.update(inventory_complete=True, final_completion_receipt=True, recorded_attempts=18, missing_attempts=[])
    audit.write_text(json.dumps(value))
    driver = tmp_path / "driver.json"
    driver.write_text(json.dumps({"driver": {"pid": os.getpid(), "process_group": os.getpgrp()}}))
    with pytest.raises(AssertionError, match="must be gone"):
        smoke.coding_gate(audit, driver_file=driver)


def test_partial_coding_gate_refuses_freeze_before_any_fixture_or_subprocess(tmp_path, monkeypatch):
    audit = tmp_path / "partial.json"
    audit.write_text(json.dumps({"checks_passed": True, "recorded_attempts": 17}))
    monkeypatch.setattr(smoke.subprocess, "check_output", lambda *args, **kwargs: pytest.fail("No subprocess allowed before gates"))
    output, work = tmp_path / "output", tmp_path / "work"
    with pytest.raises(AssertionError, match="Full18"):
        smoke.freeze(output, work, Path("unused"), Path("unused"), {name: audit for name in ("coding", "install", "parity", "mcp")})
    assert not output.exists() and not work.exists()


def test_editor_fallback_rejects_wrong_nonce_before_any_signal(tmp_path, monkeypatch):
    record = tmp_path / "ownership.json"
    record.write_text(json.dumps({"nonce": "other", "pid": 100, "process_group": 100, "detached": True}))
    monkeypatch.setattr(smoke.os, "killpg", lambda *args: pytest.fail("Cannot signal an unowned editor"))
    with pytest.raises(AssertionError, match="ownership"):
        smoke.stop_editor(record, "this-run", tmp_path / "repo")
