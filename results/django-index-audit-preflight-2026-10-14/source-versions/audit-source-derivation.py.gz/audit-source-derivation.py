#!/usr/bin/env python3
"""Independent CPU audit of the prospective Django durable-index profile.

No production extraction, normalization, ranking, index, embedding, or producer
helper is imported. Expected membership comes from the pre-output source/window
inventories and literal saved files. NumPy independently reconstructs SQLite's
normalized float32 blobs and accumulates cosine scores in float64.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tokenize

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
PREFLIGHT = ROOT / "results/django-index-preflight-2026-10-14"
MANIFEST = ROOT / "benchmarks/django_index_profile.json"
DIMENSIONS = 1024
PROVIDERS = ("bm25", "dense", "hybrid")
QUERY_PROMPT = (
    "Instruct: Given a description of code behavior, retrieve the code implementation "
    "that performs it.\nQuery:"
)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def unique_object(items):
    result = {}
    for key, value in items:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=unique_object,
                      parse_constant=lambda value: (_ for _ in ()).throw(
                          ValueError("Nonfinite JSON: " + value)))


def read(path):
    return decode(Path(path).read_text())


def typed_equal(actual, expected):
    if type(actual) is not type(expected):
        return False
    if isinstance(expected, dict):
        return actual.keys() == expected.keys() and all(
            typed_equal(actual[key], value) for key, value in expected.items())
    if isinstance(expected, list):
        return len(actual) == len(expected) and all(
            typed_equal(a, b) for a, b in zip(actual, expected, strict=True))
    return actual == expected


def physical_lines(source):
    return re.findall(r"[^\r\n]*(?:\r\n|\r|\n)|[^\r\n]+$", source)


def source_text(raw):
    encoding, _ = tokenize.detect_encoding(io.BytesIO(raw).readline)
    return raw.decode(encoding)


def document(path, symbol, text):
    return f"Path: {path}\nSymbol: {symbol}\nSource:\n{text}"


def saved_windows(inventory, sources):
    """Verify saved inventory spans and build documents without extraction code."""
    output = []
    for row in inventory:
        path, first, last = row["path"], row["start_line"], row["end_line"]
        require(type(first) is int and type(last) is int and 1 <= first <= last,
                "Invalid inventory source boundaries")
        lines = physical_lines(source_text(sources[path]))
        require(last <= len(lines), "Window extends past saved file")
        text = "".join(lines[first - 1:last])
        rendered = document(path, row["symbol"], text)
        require(row["id"] == f"{path}:{row['symbol']}:{first}-{last}",
                "Window ID not bound to source location")
        require(row["content_sha256"] == sha(text.encode()), "Frozen window content hash differs")
        require(row["document_sha256"] == sha(rendered.encode()), "Frozen rendered document hash differs")
        output.append({**row, "text": text, "document": rendered})
    require(len({row["id"] for row in output}) == len(output), "Duplicate active ID")
    require(len({row["document_sha256"] for row in output}) == len(output),
            "Expected unique rendered document inventory differs")
    return output


def mutation_states(original, manifest):
    """Derive copy-only states and cache union from exact rendered source bytes."""
    mutation = manifest["mutation"]
    path, renamed = mutation["path"], mutation["renamed_path"]
    affected = [row for row in original if row["path"] == path]
    target = [row for row in affected if row["id"] == mutation["edited_window_id"]]
    require(len(affected) == 13 and len(target) == 1, "Mutation window membership differs")
    require(target[0]["text"].count(mutation["replacement_line_before"]) == 1,
            "Mutation is not one unique line")
    edited = []
    for row in original:
        changed = dict(row)
        if row["id"] == mutation["edited_window_id"]:
            changed["text"] = row["text"].replace(mutation["replacement_line_before"],
                                                    mutation["replacement_line_after"])
            changed["content_sha256"] = sha(changed["text"].encode())
            changed["document"] = document(path, row["symbol"], changed["text"])
            changed["document_sha256"] = sha(changed["document"].encode())
            require(changed["document_sha256"] == mutation["edited_document_sha256"],
                    "Saved edit document binding differs")
        edited.append(changed)
    moved = []
    for row in edited:
        changed = dict(row)
        if row["path"] == path:
            changed["path"] = renamed
            changed["id"] = f"{renamed}:{row['symbol']}:{row['start_line']}-{row['end_line']}"
            changed["document"] = document(renamed, row["symbol"], row["text"])
            changed["document_sha256"] = sha(changed["document"].encode())
        moved.append(changed)
    # Production extraction sorts tracked paths, then preserves definition order.
    path_order = {row["id"]: position for position, row in enumerate(original)}
    moved.sort(key=lambda row: (row["path"], path_order.get(row["id"].replace(renamed, path), -1)))
    by_name = {"initial": original, "fresh_process_reopen": original,
               "saved_edit": edited, "delete_file": [row for row in edited if row["path"] != path],
               "restore_edited_file": edited, "rename_edited_file": moved,
               "rename_back": edited, "restore_pristine_file": original,
               "final_fresh_process_reopen": original}
    cache, previous_ids, result = set(), set(), []
    for expected in manifest["persistence_sequence"]:
        name = expected["stage"]
        active = by_name[name]
        hashes = {row["document_sha256"] for row in active}
        ids = {row["id"] for row in active}
        actual = {"stage": name, "total_windows": len(active), "indexed_windows": len(hashes - cache),
                  "new_unique_documents": len(hashes - cache), "reused_windows": len(hashes & cache),
                  "deleted_windows": len(previous_ids - ids), "cached_documents_after": len(cache | hashes)}
        require(all(typed_equal(actual[key], value) for key, value in expected.items()
                    if key != "forbid_document_and_query_inference"), "Independent mutation counts differ")
        result.append({**actual, "windows": active, "cached_hashes": sorted(cache | hashes),
                       "new_hashes": [row["document_sha256"] for row in active
                                      if row["document_sha256"] not in cache]})
        cache |= hashes
        previous_ids = ids
    return result


def independent_float32(values):
    """Reconstruct float32 stored unit vectors, independently of store helpers."""
    matrix = np.asarray(values)
    require(matrix.ndim == 2 and matrix.shape[1] > 0 and matrix.dtype.kind == "f",
            "Vector capture must be a real floating matrix")
    require(np.isfinite(matrix).all() and np.all(np.any(matrix != 0, axis=1)),
            "Vectors must be finite and nonzero")
    wide = matrix.astype(np.float64)
    largest = np.max(np.abs(wide), axis=1)
    scaled = wide / largest[:, None]
    lengths = np.sqrt(np.sum(scaled * scaled, axis=1))
    return (scaled / lengths[:, None]).astype("<f4")


def independent_dense(ids, document_vectors, query, limit=10):
    require(len(ids) == len(document_vectors) and len(set(ids)) == len(ids), "Dense ID inventory differs")
    documents = independent_float32(document_vectors).astype(np.float64)
    query = independent_float32(np.asarray(query).reshape(1, -1))[0].astype(np.float64)
    require(documents.shape[1] == query.shape[0], "Query dimensions differ")
    numerators = np.sum(documents * query, axis=1)
    scores = numerators / (np.sqrt(np.sum(documents * documents, axis=1))
                           * math.sqrt(float(np.sum(query * query))))
    order = sorted(range(len(ids)), key=lambda i: (-float(scores[i]), ids[i]))[:limit]
    return [{"id": ids[i], "score": float(scores[i])} for i in order]


def verify_dense(expected, observed, tolerance=3e-6):
    require(len(observed) == len(expected), "Dense top-k count differs")
    require([row["id"] for row in observed] == [row["id"] for row in expected],
            "Dense order differs; near ties are not automatically accepted")
    errors = []
    for actual, wanted in zip(observed, expected, strict=True):
        require(type(actual["score"]) is float and math.isfinite(actual["score"]), "Invalid cosine scalar")
        errors.append(abs(actual["score"] - wanted["score"]))
    require(max(errors, default=0.0) <= tolerance, "Dense cosine error exceeds fixed bound")
    return max(errors, default=0.0)


def timing_summary(samples):
    require(samples and all(type(value) is float and math.isfinite(value) and value >= 0 for value in samples),
            "Invalid finite elapsed samples")
    return {"count": len(samples), "median_s": float(np.median(samples)),
            "p95_s": float(np.percentile(samples, 95, method="linear")),
            "min_s": min(samples), "max_s": max(samples)}


def verify_clock(start, end, elapsed):
    require(type(elapsed) is float and math.isfinite(elapsed) and elapsed >= 0, "Invalid elapsed clock")
    wall_start, wall_end = datetime.fromisoformat(start["wall_utc"]), datetime.fromisoformat(end["wall_utc"])
    require(wall_start.tzinfo is not None and wall_end.tzinfo is not None, "Clock lacks timezone")
    for key in ("monotonic_s",):
        require(all(type(item[key]) is float and math.isfinite(item[key]) for item in (start, end)),
                "Invalid monotonic clock")
    monotonic = end["monotonic_s"] - start["monotonic_s"]
    wall = (wall_end - wall_start).total_seconds()
    require(monotonic >= 0 and abs(monotonic - elapsed) <= 0.01, "Elapsed is not bound to monotonic clock")
    require(abs(wall - monotonic) <= 2.0, "Wall/monotonic discontinuity invalidates timing")


def bound_artifact(descriptor, base):
    require(isinstance(descriptor, dict) and isinstance(descriptor.get("path"), str), "Missing artifact descriptor")
    value = descriptor["path"].replace("<PROJECT>", str(ROOT)).replace("<HOME>", str(Path.home()))
    path = Path(value)
    if not path.is_absolute():
        path = base / path
    raw = path.read_bytes()
    require(descriptor.get("sha256") == sha(raw), "Artifact SHA-256 differs: " + str(path))
    require(type(descriptor.get("bytes")) is int and descriptor["bytes"] == len(raw), "Artifact byte size differs")
    return path, raw


def lexical_terms(text):
    """Independent public token-splitting specification for FTS bindings."""
    separated = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1 \2", text)
    separated = re.sub(r"([a-z0-9])([A-Z])", r"\1 \2", separated)
    return re.findall(r"[a-z0-9]+", separated.lower())


def verify_sqlite_snapshot(path, expected, vectors_by_hash, metadata):
    fingerprint = sha(json.dumps(metadata, sort_keys=True, separators=(",", ":"),
                                 allow_nan=False).encode())
    with sqlite3.connect(f"file:{Path(path).resolve()}?mode=ro", uri=True) as connection:
        require(connection.execute("PRAGMA integrity_check").fetchall() == [("ok",)],
                "SQLite snapshot integrity failure")
        require(connection.execute("PRAGMA user_version").fetchone()[0] == 2, "SQLite schema differs")
        active_record = connection.execute("SELECT value FROM metadata WHERE key='active'").fetchone()
        require(active_record is not None, "No active metadata")
        active = decode(active_record[0])
        require(active.get("dimensions") == DIMENSIONS and active.get("model_fingerprint") == fingerprint
                and typed_equal(active.get("embedding"), metadata), "Stored embedding metadata differs")
        rows = connection.execute("SELECT id,position,path,symbol,start_line,end_line,text,content_hash,"
                                  "document_hash,model_fingerprint FROM snippets ORDER BY position").fetchall()
        require(len(rows) == expected["total_windows"], "Active source row count differs")
        wanted_rows = [(row["id"], i, row["path"], row["symbol"], row["start_line"], row["end_line"],
                        row["text"], row["content_sha256"], row["document_sha256"], fingerprint)
                       for i, row in enumerate(expected["windows"])]
        require(rows == wanted_rows, "Active saved source/position/document bindings differ")
        fts = dict(connection.execute("SELECT id,terms FROM snippets_fts"))
        require(len(fts) == len(rows) and fts == {
            row["id"]: " ".join(lexical_terms(f"{row['path']} {row['symbol']}\n{row['text']}"))
            for row in expected["windows"]}, "Active FTS bindings differ or stale IDs remain")
        cached = connection.execute("SELECT model_fingerprint,document_hash,dimensions,vector FROM embeddings").fetchall()
        require(len(cached) == expected["cached_documents_after"], "Cached document table count differs")
        require({row[1] for row in cached} == set(expected["cached_hashes"]), "Cached historical document union differs")
        for model, document_hash, dimensions, blob in cached:
            require(model == fingerprint and type(dimensions) is int and dimensions == DIMENSIONS,
                    "Cached vector model/dimensions differ")
            value = vectors_by_hash[document_hash]
            require(value.dtype == np.dtype("float32") and value.shape == (DIMENSIONS,),
                    "Original native vector capture must be float32/1024")
            require(np.isfinite(value).all() and np.any(value != 0), "Invalid original vector")
            require(blob == value.astype("<f8").tobytes(), "Cached vector differs from original native float32 output")
        dense = connection.execute("SELECT snippet_id,model_fingerprint,dimensions,vector FROM active_vectors").fetchall()
        require(len(dense) == len(rows) and {row[0] for row in dense} == {row[0] for row in rows},
                "Active dense ID set differs or stale/deleted IDs remain")
        documents = {row["id"]: row["document_sha256"] for row in expected["windows"]}
        for identifier, model, dimensions, blob in dense:
            require(model == fingerprint and type(dimensions) is int and dimensions == DIMENSIONS,
                    "Active dense model/dimensions differ")
            expected_blob = independent_float32(vectors_by_hash[documents[identifier]].reshape(1, -1))[0].tobytes()
            require(blob == expected_blob, "Active normalized float32 vector differs")
    return {"active_windows": len(rows), "cached_documents": len(cached), "model_fingerprint": fingerprint}


def verify_delivered(response, query, sources):
    require(response.get("query") == query["query"] and response.get("retrieval") in PROVIDERS,
            "Delivered query/provider differs")
    require(response.get("rerank") is False and response.get("source_budget") == 12000,
            "Delivered reranking/source budget differs")
    rows = response["results"]
    require(len(rows) <= 5, "Delivered result cap exceeded")
    total = 0
    for row in rows:
        path = row["path"]
        require(path in sources and row.get("origin") == "retrieval" and row.get("related_to") is None,
                "Delivered source scope/dependency differs")
        first, last = row["start_line"], row["end_line"]
        require(type(first) is int and type(last) is int and 1 <= first <= last, "Invalid delivered span")
        lines = physical_lines(source_text(sources[path]))
        require(last <= len(lines), "Delivered span extends beyond saved file")
        text = "".join(lines[first - 1:last])
        require(row["source"] == text and row["source_hash"] == sha(text.encode()),
                "Delivered source bytes/location/hash differ")
        require(type(row["truncated"]) is bool, "Truncation flag must be boolean")
        window_end = row["window_end_line"]
        require(type(window_end) is int and last <= window_end <= len(lines), "Saved window boundary differs")
        full = "".join(lines[first - 1:window_end])
        require(row["content_hash"] == sha(full.encode()) and row["truncated"] is (text != full),
                "Saved window content/truncation binding differs")
        require(row["id"] == f"{path}:{row['symbol']}:{first}-{window_end}",
                "Delivered snippet ID/location differs")
        total += len(text)
    require(total <= 12000 and type(response.get("total_source_chars")) is int
            and response["total_source_chars"] == total, "Actual delivered source character accounting differs")
    usage = response["token_usage"]
    require(usage.get("encoding") == "cl100k_base" and type(usage.get("tokens")) is int
            and 0 <= usage["tokens"] <= 2000 and usage.get("budget") == 2000,
            "Actual delivered token cap differs")
    # Import a CPU tokenizer only; this path is outside every measured sample.
    import tiktoken
    fields = ("path", "symbol", "start_line", "end_line", "source", "source_hash", "truncated")
    compact_rows = []
    for row in rows:
        compact = {key: row[key] for key in fields}
        compact.update(origin=row.get("origin", "retrieval"), related_to=row.get("related_to"))
        for key in ("source_origin", "buffer_version", "buffer_hash"):
            if key in row:
                compact[key] = row[key]
        compact_rows.append(compact)
    compact = {"query": response["query"], "match_status": response.get("match_status", "candidates"),
               "results": compact_rows, "budget_exhausted": response.get("budget_exhausted", False),
               "token_usage": usage}
    if "scope" in response:
        compact["scope"] = response["scope"]
    payload = json.dumps(compact, ensure_ascii=False, allow_nan=False, separators=(",", ":"))
    tokens = len(tiktoken.get_encoding("cl100k_base").encode(payload, disallowed_special=()))
    require(tokens == usage["tokens"], "Independent compact-payload token count differs")
    coverage = []
    for group in query["target_groups"]:
        coverage.append(any(any(row["path"] == target["path"] and row["symbol"] == target["symbol"]
                                and row["start_line"] <= target["evidence_lines"][0]
                                and row["end_line"] >= target["evidence_lines"][1]
                                for row in rows) for target in group))
    return {"tokens": tokens, "source_chars": total, "groups": coverage, "complete": all(coverage)}


def run(command):
    return subprocess.run(command, capture_output=True, text=True, check=True, timeout=30).stdout.strip()


def prospective_inputs(manifest_path=MANIFEST, preflight=PREFLIGHT, original=None):
    manifest = read(manifest_path)
    freeze = read(preflight / "freeze.json")
    for relative, descriptor in freeze["artifacts"].items():
        path = ROOT / relative
        raw = path.read_bytes()
        require(sha(raw) == descriptor["sha256"] and len(raw) == descriptor["bytes"],
                "Frozen prospective input differs: " + relative)
    require(manifest["source_window_count"] == 9097 and manifest["unique_document_count"] == 9097,
            "Frozen corpus counts differ")
    source = Path(original) if original else ROOT / manifest["corpus"]
    require(run(["git", "-C", str(source), "rev-parse", "HEAD"]) == manifest["revision"], "Original source commit differs")
    require(not run(["git", "-C", str(source), "status", "--porcelain"]), "Original source fixture is dirty")
    inventory = read(preflight / "source-inventory.json")
    names = run(["git", "-C", str(source), "ls-files", "--", "django"]).splitlines()
    require(sorted(name for name in names if name.endswith(".py")) == [row["path"] for row in inventory],
            "Original tracked Python membership differs")
    sources = {}
    for row in inventory:
        raw = (source / row["path"]).read_bytes()
        require(sha(raw) == row["sha256"] and len(raw) == row["bytes"], "Original saved file differs")
        require(len(physical_lines(source_text(raw))) == row["physical_lines"], "Physical source lines differ")
        sources[row["path"]] = raw
    windows = decode(gzip.decompress((preflight / "window-inventory.json.gz").read_bytes()))
    originals = saved_windows(windows, sources)
    mutation = manifest["mutation"]
    raw_before = sources[mutation["path"]]
    before = mutation["replacement_line_before"].encode()
    after = mutation["replacement_line_after"].encode()
    require(raw_before.count(before) == 1, "Saved file mutation line is not unique")
    raw_edited = raw_before.replace(before, after)
    require(sha(raw_before) == mutation["original_file_sha256"]
            and sha(raw_edited) == mutation["edited_file_sha256"], "Saved mutation file hash differs")
    require(raw_edited == gzip.decompress((preflight / "mutation-sources/locmem.saved-edit.py.gz").read_bytes()),
            "Retained saved edit differs from independent literal mutation")
    for query in manifest["queries"]:
        for group in query["target_groups"]:
            for target in group:
                raw = sources[target["path"]]
                require(sha(raw) == target["source_file_sha256"], "Authored example saved file hash differs")
                first, last = target["evidence_lines"]
                span = "".join(physical_lines(source_text(raw))[first - 1:last])
                require(sha(span.encode()) == target["evidence_sha256"], "Authored example evidence span differs")
                require(any(row["id"] == target["eligible_window_id"] and row["symbol"] == target["symbol"]
                            and row["start_line"] <= first and row["end_line"] >= last
                            for row in originals), "Authored example lacks a complete eligible window")
    stages = mutation_states(originals, manifest)
    return manifest, sources, stages


def audit(study):
    """Final artifact wiring is deliberately completed before native collection."""
    raise ValueError("Runner evidence schema has not yet been frozen; native outcomes cannot be certified")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--study", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--preflight", action="store_true")
    arguments = parser.parse_args(argv)
    require(not arguments.output.exists(), "Refuse replacing an audit attempt")
    result = {"kind": "independent_django_index_profile_audit", "passed": False,
              "created_at_utc": datetime.now(timezone.utc).isoformat(),
              "auditor_sha256": sha(Path(__file__).read_bytes()),
              "production_helpers_imported": False, "model_imports_or_inference": False}
    try:
        if arguments.preflight:
            manifest, _, stages = prospective_inputs()
            result.update(prospective_only=True, outcomes_observed=False,
                          window_count=manifest["source_window_count"],
                          independently_derived_stages=[{key: value for key, value in row.items()
                                                        if key not in ("windows", "cached_hashes", "new_hashes")}
                                                       for row in stages])
        else:
            require(arguments.study is not None, "--study is required for outcomes")
            result.update(audit(arguments.study))
        result["passed"] = True
    except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError) as error:
        result["error"] = f"{type(error).__name__}: {error}"
    arguments.output.parent.mkdir(parents=True, exist_ok=True)
    arguments.output.write_text(json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n")
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
