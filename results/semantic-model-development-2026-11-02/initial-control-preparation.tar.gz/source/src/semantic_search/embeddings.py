"""Pinned, unquantized Qwen3 embeddings on Apple Silicon.

The query formatting, last-token pooling, and 8192-token example follow
https://huggingface.co/Qwen/Qwen3-Embedding-0.6B . Documents get no instruction.
MLX is imported and the checkpoint loaded only on the first nonempty request.
"""
from __future__ import annotations

import copy
import hashlib
import importlib.metadata
import json
from pathlib import Path
import time

import numpy as np

MODEL_ID = "Qwen/Qwen3-Embedding-0.6B"
MODEL_REVISION = "97b0c614be4d77ee51c0cef4e5f07c00f9eb65b3"
RUNTIME_VERSION = "0.1.0"
MAX_TOKENS = 8192
MAX_PADDED_TOKENS = 8192
DIMENSIONS = 1024
QUERY_INSTRUCTION = (
    "Given a description of code behavior, retrieve the code implementation that performs it."
)
QUERY_PROMPT = f"Instruct: {QUERY_INSTRUCTION}\nQuery:"
PROVENANCE_FILE = "semantic_search_checkpoint.json"
DEFAULT_MODEL_PATH = (
    Path(__file__).resolve().parents[2] / ".cache/models/qwen3-embedding-0.6b"
)


def normalize_rows(vectors: np.ndarray) -> np.ndarray:
    """Return finite unit vectors in float32; reject unusable model outputs."""
    vectors = np.asarray(vectors, dtype=np.float32)
    if vectors.ndim != 2 or not np.isfinite(vectors).all():
        raise ValueError("Embedding output must be a finite matrix")
    norms = np.linalg.norm(vectors, axis=1, keepdims=True)
    if np.any(norms == 0):
        raise ValueError("Model returned a zero embedding")
    return vectors / norms


def last_token_pool(hidden: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """Pool the last valid token with either left or right padding.

    This CPU helper also makes padding behavior testable without loading MLX.
    The model path applies the same indexing before materializing on the CPU.
    """
    hidden = np.asarray(hidden)
    mask = np.asarray(mask)
    if hidden.ndim != 3 or mask.shape != hidden.shape[:2]:
        raise ValueError("Hidden states and attention mask have incompatible shapes")
    if mask.shape[1] == 0 or np.any(mask.sum(axis=1) == 0):
        raise ValueError("Every embedding input must contain at least one token")
    positions = np.where(mask != 0, np.arange(mask.shape[1]), -1).max(axis=1)
    return hidden[np.arange(hidden.shape[0]), positions]


class QwenEmbedder:
    def __init__(self, model_path=None, batch_size=4, progress=True, *,
                 max_padded_tokens=MAX_PADDED_TOKENS):
        if not isinstance(batch_size, int) or isinstance(batch_size, bool) or batch_size < 1:
            raise ValueError("batch_size must be a positive integer")
        if type(max_padded_tokens) is not int or max_padded_tokens < MAX_TOKENS:
            raise ValueError(f"max_padded_tokens must be an integer of at least {MAX_TOKENS}")
        self.model_path = Path(model_path) if model_path is not None else DEFAULT_MODEL_PATH
        self.batch_size = batch_size
        self.max_padded_tokens = max_padded_tokens
        self.progress = progress
        self._model = None
        self._tokenizer = None
        self._mx = None
        self._checkpoint_verified = False

    @property
    def metadata(self):
        versions = {}
        for package in ("mlx-embeddings", "mlx", "mlx-metal", "transformers", "numpy"):
            try:
                versions[package] = importlib.metadata.version(package)
            except importlib.metadata.PackageNotFoundError:
                versions[package] = None
        return {
            "id": MODEL_ID, "revision": MODEL_REVISION,
            "weights_dtype": "bfloat16", "quantized": False,
            "runtime": "mlx-embeddings", "runtime_version": RUNTIME_VERSION,
            "packages": versions, "dimensions": DIMENSIONS,
            "query_instruction": QUERY_INSTRUCTION, "query_prompt": QUERY_PROMPT,
            "document_prompt": None, "pooling": "last non-padding token",
            "normalization": "L2, float32", "max_tokens": MAX_TOKENS,
            "truncation": "right", "padding_side": "right",
            "add_special_tokens": True, "batch_size": self.batch_size,
            "max_padded_tokens": self.max_padded_tokens,
            "batch_order": "stable ascending token length; restore input order",
            "batch_policy": ("stable ascending token length; greedy groups capped by batch_size and "
                             "longest_token_length * document_count <= max_padded_tokens; restore input order"),
            "checkpoint_validation": "pinned Hub download provenance; original unquantized config",
        }

    def _ensure_loaded(self):
        if self._model is not None:
            return
        provenance = self.model_path / PROVENANCE_FILE
        if not provenance.is_file():
            raise FileNotFoundError(
                f"Pinned embedding checkpoint missing at {self.model_path}. "
                "Run .venv/bin/python scripts/setup_embeddings.py first."
            )
        record = json.loads(provenance.read_text())
        if record.get("id") != MODEL_ID or record.get("revision") != MODEL_REVISION:
            raise ValueError("Embedding checkpoint provenance does not match the pinned model")
        config = json.loads((self.model_path / "config.json").read_text())
        if (config.get("model_type") != "qwen3" or config.get("hidden_size") != DIMENSIONS
                or config.get("quantization") or config.get("quantization_config")):
            raise ValueError("Expected original, unquantized Qwen3-Embedding-0.6B weights")
        if importlib.metadata.version("mlx-embeddings") != RUNTIME_VERSION:
            raise ValueError("Unexpected mlx-embeddings version; rerun scripts/setup_embeddings.py")
        import mlx.core as mx
        from mlx_embeddings import load

        self._model, self._tokenizer = load(
            str(self.model_path),
            tokenizer_config={"padding_side": "right", "truncation_side": "right"},
        )
        self._mx = mx
        self._checkpoint_verified = True

    def _embed_batch(self, token_ids):
        mx = self._mx
        # Right padding retains every real token's position and avoids fully
        # masked causal attention rows for leading pad tokens in this runtime.
        batch = self._tokenizer.pad({"input_ids": token_ids}, padding=True,
                                    return_attention_mask=True, return_tensors="np")
        mask = np.asarray(batch["attention_mask"])
        positions = mask.sum(axis=1).astype(np.int32) - 1
        outputs = self._model(mx.array(batch["input_ids"]), mx.array(mask))
        pooled = outputs.last_hidden_state[mx.arange(len(token_ids)), mx.array(positions)]
        pooled = pooled.astype(mx.float32)
        mx.eval(pooled)
        vectors = normalize_rows(np.asarray(pooled))
        del outputs, pooled
        return vectors

    def _embed_texts(self, texts, *, cancel_check=None, progress_callback=None,
                     batch_callback=None, forward_observer=None):
        """Encode texts, optionally observing scheduled native forwards.

        Observation events are isolated dictionaries. ``started`` precedes the
        native call; a started event alone therefore does not prove model work
        if its observer raises. Terminal ``completed``/``failed`` events count
        actual calls. Their duration excludes the started observer and includes
        native output validation. Completion precedes post-forward cancellation
        and existing checkpoint/progress callbacks. Observer failures propagate;
        an observer failure while reporting a model error is chained as the
        cause of that original model error. No vectors or text are exposed.
        """
        if not isinstance(texts, list) or any(not isinstance(t, str) or not t.strip() for t in texts):
            raise ValueError("Embedding inputs must be a list of nonempty strings")
        if forward_observer is not None and not callable(forward_observer):
            raise TypeError("forward_observer must be callable")
        if not texts:
            return np.empty((0, DIMENSIONS), dtype=np.float32)
        observed_start = time.perf_counter() if forward_observer is not None else None
        input_hashes = ([hashlib.sha256(text.encode()).hexdigest() for text in texts]
                        if forward_observer is not None else None)
        self._ensure_loaded()
        encoded = self._tokenizer(texts, padding=False, truncation=True,
                                  max_length=MAX_TOKENS, add_special_tokens=True)
        ids = encoded["input_ids"]
        if any(not tokens for tokens in ids):
            raise ValueError("Every embedding input must contain at least one token")
        if any(len(tokens) > MAX_TOKENS for tokens in ids):
            raise ValueError(f"Tokenizer exceeded the {MAX_TOKENS}-token embedding limit")
        order = sorted(range(len(ids)), key=lambda i: (len(ids[i]), i))
        output = np.empty((len(texts), DIMENSIONS), dtype=np.float32)
        reported = completed = start = forward_index = 0
        while start < len(order):
            if cancel_check is not None:
                cancel_check()
            end = min(start + self.batch_size, len(order))
            # A long document must not multiply its padded length by the fixed
            # document batch count. Retain each document's existing token limit,
            # reducing only the number of documents forwarded together.
            while len(ids[order[end - 1]]) * (end - start) > self.max_padded_tokens:
                end -= 1
            indices = order[start:end]
            if forward_observer is None:
                vectors = self._embed_batch([ids[i] for i in indices])
                if vectors.shape != (len(indices), DIMENSIONS):
                    raise ValueError(f"Unexpected Qwen embedding shape: {vectors.shape}")
                output[indices] = vectors
            else:
                lengths = [len(ids[i]) for i in indices]
                identity = {
                    "schema": "qwen_embedding_forward_v1", "forward_index": forward_index,
                    "input_count": len(texts), "batch_input_count": len(indices),
                    "input_indices": indices.copy(), "token_lengths": lengths,
                    "padded_tokens": max(lengths) * len(indices),
                    "padded_shape": [len(indices), max(lengths)],
                    "expected_output_shape": [len(indices), DIMENSIONS],
                    "input_sha256": [input_hashes[i] for i in indices],
                    "token_ids_sha256": [hashlib.sha256(json.dumps(
                        [int(token) for token in ids[i]], separators=(",", ":")
                    ).encode()).hexdigest() for i in indices],
                }

                def observe(status, **details):
                    # Every callback owns its complete event. Mutation cannot
                    # alter the schedule, another event, or returned vectors.
                    event = {**identity, "status": status,
                             "elapsed_seconds": time.perf_counter() - observed_start,
                             **details}
                    forward_observer(copy.deepcopy(event))

                # A failing observer stops admission before model work. A
                # started event alone is not evidence of a completed forward.
                observe("started")
                native_start = time.perf_counter()
                failure_phase = "forward"
                try:
                    vectors = self._embed_batch([ids[i] for i in indices])
                    failure_phase = "output_validation"
                    if vectors.shape != (len(indices), DIMENSIONS):
                        raise ValueError(f"Unexpected Qwen embedding shape: {vectors.shape}")
                    output[indices] = vectors
                except BaseException as error:
                    duration = time.perf_counter() - native_start
                    try:
                        observe("failed", duration_seconds=duration,
                                failure_phase=failure_phase,
                                exception_type=f"{type(error).__module__}.{type(error).__qualname__}")
                    except BaseException as observer_error:
                        # Preserve the original model/validation exception while
                        # making the failed ledger observer visible as its cause.
                        raise error from observer_error
                    raise
                observe("completed", duration_seconds=time.perf_counter() - native_start,
                        output_shape=list(vectors.shape), output_dtype=str(vectors.dtype))
                forward_index += 1
            # Token-length batches otherwise accumulate unused Metal allocations
            # across many shapes. Keep weights resident, release batch buffers.
            if len(texts) > 1 and self._mx is not None:
                self._mx.clear_cache()
            if cancel_check is not None:
                cancel_check()
            if batch_callback is not None:
                # Report native batch positions in the original request, before
                # progress observers can cancel. Checkpoint consumers own these
                # copies and cannot alter the output or the remaining schedule.
                batch_callback(indices.copy(), output[indices].copy())
            completed += len(indices)
            start = end
            if progress_callback is not None:
                progress_callback(completed, len(texts))
            if (self.progress and len(texts) > 1
                    and (completed - reported >= 32 or completed == len(texts))):
                print(f"Embedded {completed}/{len(texts)} documents", flush=True)
                reported = completed
        return output

    def embed_documents(self, texts: list[str], *, cancel_check=None,
                        progress_callback=None, batch_callback=None,
                        forward_observer=None) -> np.ndarray:
        """Embed in input order; optionally checkpoint each completed native batch.

        Checkpoints receive isolated original input indices and float32 vectors.
        They run after cancellation checks and before progress observers.
        """
        try:
            return self._embed_texts(texts, cancel_check=cancel_check,
                                    progress_callback=progress_callback,
                                    batch_callback=batch_callback,
                                    forward_observer=forward_observer)
        finally:
            if self._mx is not None:
                self._mx.clear_cache()

    def embed_query(self, query: str, *, forward_observer=None) -> np.ndarray:
        if not isinstance(query, str) or not query.strip():
            raise ValueError("Query must be a nonempty string")
        kwargs = {} if forward_observer is None else {"forward_observer": forward_observer}
        return self._embed_texts([QUERY_PROMPT + query], **kwargs)[0]

    def embed_queries(self, queries: list[str], *, cancel_check=None,
                      forward_observer=None) -> np.ndarray:
        """Embed queries in input order with the existing query instruction.

        Each input retains the single-query token limit. The existing batch
        count and padded-token limits can require more than one model forward;
        cancellation is checked before and after each forward. An empty list
        returns an empty matrix without loading the checkpoint.
        """
        if (not isinstance(queries, list)
                or any(not isinstance(query, str) or not query.strip() for query in queries)):
            raise ValueError("Queries must be a list of nonempty strings")
        return self._embed_texts([QUERY_PROMPT + query for query in queries],
                                cancel_check=cancel_check, forward_observer=forward_observer)

    def close(self):
        """Release embedding weights before running another GPU experiment."""
        self._model = self._tokenizer = None
        if self._mx is not None:
            self._mx.clear_cache()
        self._mx = None
        self._checkpoint_verified = False
